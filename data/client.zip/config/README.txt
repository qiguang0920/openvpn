This directory or its subdirectories should contain OpenVPN
configuration files each having an extension of .ovpn

When OpenVPN is started as a service, a separate OpenVPN
process will be instantiated for each configuration file.

When OpenVPN GUI is started configs in this directory are added
to the list of available connections
